import Link from 'next/link';
import { Metadata } from 'next';
import { ArrowRight, Calculator, MapPin, BookOpen, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { generatePageMetadata } from '@/lib/seo';
import { SchemaMarkup } from '@/components/seo/SchemaMarkup';
import { buildWebPageSchema, buildOrganizationSchema } from '@/lib/schema';
import { popularStates, popularCities } from '@/config/navigation';
import { siteConfig } from '@/config/siteConfig';

export const metadata: Metadata = generatePageMetadata({
  title: 'Free Buy vs. Rent Calculator for All 50 States',
  description: siteConfig.description,
  path: '/',
});

export default function HomePage() {
  return (
    <>
      <SchemaMarkup
        data={buildWebPageSchema(
          'BuyOrRent - Free Buy vs. Rent Calculator',
          siteConfig.description,
          siteConfig.baseUrl
        )}
      />
      <SchemaMarkup data={buildOrganizationSchema()} />

      <section className="border-b bg-gradient-to-b from-teal-50/60 to-background">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Should You Buy or Rent?
            </h1>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Free, independent calculator covering all 50 states and 15 major
              cities. No ads, no affiliate links, no hidden agenda. Just transparent
              math to help you make a smarter housing decision.
            </p>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <Link href="/buy-vs-rent">
                <Button size="lg" className="bg-teal-600 hover:bg-teal-700">
                  <Calculator className="mr-2 h-4 w-4" />
                  Use the Calculator
                </Button>
              </Link>
              <Link href="/how-this-tool-works">
                <Button variant="outline" size="lg">
                  How It Works
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <div className="grid gap-6 sm:grid-cols-3">
            {[
              {
                icon: Calculator,
                title: 'Transparent Calculator',
                text: 'All assumptions visible. All math explained. No black boxes.',
              },
              {
                icon: MapPin,
                title: 'Local Market Data',
                text: 'State and city-level data so you can compare where you actually live.',
              },
              {
                icon: ShieldCheck,
                title: 'Independent & Unaffiliated',
                text: 'No lender partnerships. No referral fees. We do not sell your data.',
              },
            ].map((card) => (
              <div
                key={card.title}
                className="rounded-lg border bg-card p-6 shadow-sm"
              >
                <card.icon className="h-8 w-8 text-teal-600" />
                <h2 className="mt-3 text-lg font-semibold text-foreground">
                  {card.title}
                </h2>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {card.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <h2 className="mb-6 text-2xl font-bold tracking-tight text-foreground">
            Browse by State
          </h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {popularStates.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="group flex items-center justify-between rounded-lg border bg-card p-3 transition-colors hover:border-teal-300 hover:bg-teal-50/30"
              >
                <span className="text-sm font-medium text-foreground group-hover:text-teal-700">
                  {link.label}
                </span>
                <ArrowRight className="h-3.5 w-3.5 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-teal-600" />
              </Link>
            ))}
          </div>
          <p className="mt-4 text-sm text-muted-foreground">
            <Link
              href="/buy-vs-rent"
              className="font-medium text-teal-600 hover:underline"
            >
              View all 50 states
            </Link>
          </p>
        </div>
      </section>

      <section className="border-b">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <h2 className="mb-6 text-2xl font-bold tracking-tight text-foreground">
            Browse by City
          </h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {popularCities.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="group flex items-center justify-between rounded-lg border bg-card p-3 transition-colors hover:border-teal-300 hover:bg-teal-50/30"
              >
                <span className="text-sm font-medium text-foreground group-hover:text-teal-700">
                  {link.label}
                </span>
                <ArrowRight className="h-3.5 w-3.5 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-teal-600" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <h2 className="mb-6 text-2xl font-bold tracking-tight text-foreground">
            Guides & Resources
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                title: 'Buying Guide',
                href: '/buying-guide',
                desc: 'Step-by-step guide to purchasing a home.',
              },
              {
                title: 'Renting Guide',
                href: '/renting-guide',
                desc: 'What to know before signing a lease.',
              },
              {
                title: 'First-Time Buyer Guide',
                href: '/first-time-home-buyer-guide',
                desc: 'Special considerations for first-time buyers.',
              },
              {
                title: 'Moving Costs Guide',
                href: '/moving-costs-guide',
                desc: 'Budget for the costs people forget.',
              },
            ].map((guide) => (
              <Link
                key={guide.href}
                href={guide.href}
                className="group rounded-lg border bg-card p-5 transition-colors hover:border-teal-300 hover:bg-teal-50/30"
              >
                <BookOpen className="h-5 w-5 text-teal-600" />
                <h3 className="mt-2 font-semibold text-foreground group-hover:text-teal-700">
                  {guide.title}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">{guide.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
