import { MetadataRoute } from 'next';
import { states } from '@/config/states';
import { cities } from '@/config/cities';
import { siteConfig } from '@/config/siteConfig';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteConfig.baseUrl;
  const now = new Date().toISOString();

  const staticPages: MetadataRoute.Sitemap = [
    { url: base, lastModified: now, changeFrequency: 'monthly', priority: 1.0 },
    { url: `${base}/buy-vs-rent`, lastModified: now, changeFrequency: 'weekly', priority: 1.0 },
    { url: `${base}/about`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/editorial-policy`, lastModified: now, changeFrequency: 'monthly', priority: 0.5 },
    { url: `${base}/methodology`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/faq`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/contact`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${base}/disclaimer`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${base}/how-this-tool-works`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/renting-guide`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/buying-guide`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/first-time-home-buyer-guide`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
    { url: `${base}/moving-costs-guide`, lastModified: now, changeFrequency: 'monthly', priority: 0.6 },
  ];

  const statePages: MetadataRoute.Sitemap = states.map((state) => ({
    url: `${base}/buy-vs-rent/${state.slug}`,
    lastModified: now,
    changeFrequency: 'monthly',
    priority: 0.8,
  }));

  const cityPages: MetadataRoute.Sitemap = cities.map((city) => ({
    url: `${base}/buy-vs-rent/${city.stateSlug}/${city.slug}`,
    lastModified: now,
    changeFrequency: 'monthly',
    priority: 0.8,
  }));

  return [...staticPages, ...statePages, ...cityPages];
}
