import { Metadata } from 'next';
import { generatePageMetadata } from '@/lib/seo';
import { Breadcrumb } from '@/components/layout/Breadcrumb';
import { BlufSummary } from '@/components/content/BlufSummary';
import { FaqModule } from '@/components/content/FaqModule';
import { InternalLinks } from '@/components/content/InternalLinks';
import { nationalFaq, toolFaq, aboutFaq } from '@/config/faqData';

export const metadata: Metadata = generatePageMetadata({
  title: 'Frequently Asked Questions',
  description:
    'Answers to common questions about buying vs. renting, how our calculator works, data sources, and limitations.',
  path: '/faq',
});

export default function FaqPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'FAQ', href: '/faq' },
        ]}
      />

      <h1 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
        Frequently Asked Questions
      </h1>

      <BlufSummary
        verdict="Find answers to common questions about buying vs. renting, how our calculator works, and where our data comes from."
      />

      <FaqModule items={nationalFaq} heading="Buy vs. Rent Questions" />

      <FaqModule items={toolFaq} heading="Calculator Questions" />

      <FaqModule items={aboutFaq} heading="About This Site" />

      <InternalLinks
        heading="Related Pages"
        links={[
          { label: 'Buy vs. Rent Calculator', href: '/buy-vs-rent', description: 'Use the calculator.' },
          { label: 'Methodology', href: '/methodology', description: 'Our full calculation methodology.' },
          { label: 'How This Tool Works', href: '/how-this-tool-works', description: 'Step-by-step walkthrough.' },
        ]}
      />
    </div>
  );
}
