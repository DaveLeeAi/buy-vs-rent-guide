import { FaqItem } from './types';

export const nationalFaq: FaqItem[] = [
  {
    question: 'Should I buy or rent a home?',
    answer:
      'There is no universal answer. Buying is typically better if you plan to stay in one place for 5+ years, have a stable income, and can afford the down payment and ongoing costs. Renting offers flexibility, lower upfront costs, and freedom from maintenance responsibilities. The right choice depends on your personal finances, local market conditions, and how long you plan to stay.',
  },
  {
    question: 'How does the buy vs. rent calculator work?',
    answer:
      'The calculator compares the total cost of buying (mortgage payments, property taxes, insurance, maintenance, and opportunity cost of the down payment) against the total cost of renting (monthly rent plus renter\'s insurance, with assumed annual rent increases) over your chosen time horizon. It factors in home appreciation, tax implications, and investment returns on savings to determine which option builds more wealth.',
  },
  {
    question: 'What is the price-to-rent ratio?',
    answer:
      'The price-to-rent ratio divides the median home price by the annual rent for a comparable property. A ratio below 15 strongly favors buying, 15-20 is moderate, and above 20 suggests renting may be more cost-effective. This is a quick screening tool, not a definitive answer.',
  },
  {
    question: 'What costs does this calculator include?',
    answer:
      'The calculator accounts for mortgage principal and interest, property taxes, homeowners insurance (estimated), maintenance costs, HOA fees if applicable, and the opportunity cost of the down payment. On the rent side, it includes monthly rent, renter\'s insurance, and assumed annual rent increases.',
  },
  {
    question: 'What costs does this calculator NOT include?',
    answer:
      'This tool does not account for your specific tax situation, local tax deductions, closing costs on purchase or sale, moving costs, renovation expenses, specific insurance quotes, or emotional factors. It uses approximate averages and should be supplemented with professional financial advice.',
  },
  {
    question: 'How accurate is this calculator?',
    answer:
      'This calculator provides directional guidance using reasonable assumptions and publicly available data. It is not a substitute for professional financial advice. Actual costs will vary based on your specific circumstances, exact location, credit score, and market conditions at the time of purchase.',
  },
  {
    question: 'What is the break-even point?',
    answer:
      'The break-even point is the number of years after which buying becomes cheaper than renting on a total cost basis. Before this point, you would have spent less money renting. After this point, the accumulated equity and appreciation from buying outweigh the ongoing costs.',
  },
  {
    question: 'Should I consider buying even if the calculator says renting is cheaper?',
    answer:
      'Possibly. The calculator measures financial cost, but homeownership provides non-financial benefits: stability, the ability to modify your home, potential school district access, and a sense of community. Some people rationally choose to buy even when renting is slightly cheaper financially.',
  },
];

export const toolFaq: FaqItem[] = [
  {
    question: 'How should I interpret the results?',
    answer:
      'Use the results as one input in your decision, not the final word. If the numbers are close (within 10%), non-financial factors should drive your decision. If one option is clearly cheaper over your time horizon, that is a strong signal worth considering.',
  },
  {
    question: 'What mortgage rate should I use?',
    answer:
      'Use the rate you have been quoted or pre-approved for. If you have not spoken with a lender yet, use the current average 30-year fixed rate as a starting point. Your actual rate will depend on your credit score, down payment, and loan type.',
  },
  {
    question: 'What investment return rate should I assume?',
    answer:
      'A reasonable long-term assumption for a diversified stock portfolio is 7-8% annual nominal return. More conservative investors might use 5-6%. The tool defaults to 7%, which represents a common benchmark for long-term equity returns before inflation.',
  },
  {
    question: 'Can I use this tool for investment properties?',
    answer:
      'This tool is designed for primary residence decisions. Investment property analysis involves different tax treatment, financing terms, and return expectations. Consult a financial advisor for investment property analysis.',
  },
];

export const aboutFaq: FaqItem[] = [
  {
    question: 'Who created this tool?',
    answer:
      'This tool was created by an independent editorial team focused on transparent housing finance education. We have no financial relationships with lenders, real estate companies, or mortgage providers.',
  },
  {
    question: 'How is this site funded?',
    answer:
      'This site is currently an independent project. We do not accept payment from lenders or real estate companies, and our analysis is not influenced by any financial relationships.',
  },
  {
    question: 'How often is the data updated?',
    answer:
      'Market data is reviewed quarterly. The underlying calculation methodology is reviewed annually. Last updated: April 2025.',
  },
];
