import { NavLink, NavSection } from './types';

export const primaryNav: NavLink[] = [
  { label: 'Home', href: '/' },
  { label: 'Buy vs. Rent', href: '/buy-vs-rent' },
  { label: 'Guides', href: '/buying-guide' },
  { label: 'About', href: '/about' },
];

export const footerSections: NavSection[] = [
  {
    title: 'Tools',
    links: [
      { label: 'Buy vs. Rent Calculator', href: '/buy-vs-rent' },
      { label: 'How This Tool Works', href: '/how-this-tool-works' },
    ],
  },
  {
    title: 'Guides',
    links: [
      { label: 'Renting Guide', href: '/renting-guide' },
      { label: 'Buying Guide', href: '/buying-guide' },
      { label: 'First-Time Buyer Guide', href: '/first-time-home-buyer-guide' },
      { label: 'Moving Costs Guide', href: '/moving-costs-guide' },
    ],
  },
  {
    title: 'Trust & Transparency',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Editorial Policy', href: '/editorial-policy' },
      { label: 'Methodology', href: '/methodology' },
      { label: 'FAQ', href: '/faq' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { label: 'Disclaimer', href: '/disclaimer' },
      { label: 'Contact', href: '/contact' },
    ],
  },
];

export const popularStates: NavLink[] = [
  { label: 'California', href: '/buy-vs-rent/california' },
  { label: 'Texas', href: '/buy-vs-rent/texas' },
  { label: 'Florida', href: '/buy-vs-rent/florida' },
  { label: 'New York', href: '/buy-vs-rent/new-york' },
  { label: 'Illinois', href: '/buy-vs-rent/illinois' },
  { label: 'Pennsylvania', href: '/buy-vs-rent/pennsylvania' },
  { label: 'Georgia', href: '/buy-vs-rent/georgia' },
  { label: 'North Carolina', href: '/buy-vs-rent/north-carolina' },
  { label: 'Arizona', href: '/buy-vs-rent/arizona' },
  { label: 'Colorado', href: '/buy-vs-rent/colorado' },
];

export const popularCities: NavLink[] = [
  { label: 'New York City', href: '/buy-vs-rent/new-york/new-york' },
  { label: 'Los Angeles', href: '/buy-vs-rent/california/los-angeles' },
  { label: 'Chicago', href: '/buy-vs-rent/illinois/chicago' },
  { label: 'Houston', href: '/buy-vs-rent/texas/houston' },
  { label: 'Phoenix', href: '/buy-vs-rent/arizona/phoenix' },
  { label: 'Miami', href: '/buy-vs-rent/florida/miami' },
  { label: 'Dallas', href: '/buy-vs-rent/texas/dallas' },
  { label: 'Denver', href: '/buy-vs-rent/colorado/denver' },
  { label: 'Atlanta', href: '/buy-vs-rent/georgia/atlanta' },
  { label: 'Austin', href: '/buy-vs-rent/texas/austin' },
];
