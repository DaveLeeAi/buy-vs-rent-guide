import { CityConfig } from './types';

export const cities: CityConfig[] = [
  {
    slug: 'new-york',
    name: 'New York City',
    stateSlug: 'new-york',
    stateName: 'New York',
    medianHomePrice: 750000,
    medianMonthlyRent: 3200,
    priceToRentRatio: 19.5,
    avgAnnualAppreciation: 3.8,
    propertyTaxRate: 0.88,
    neighborhoodContext:
      'The NYC market includes five boroughs with dramatically different price levels. Manhattan is the most expensive, while the outer boroughs offer more moderate entry points.',
    blufVerdict:
      'Renting is financially smarter than buying in most of NYC for stays under 7-10 years. High prices, co-op fees, and steep closing costs shift the break-even point further out than in most U.S. cities.',
    keyFacts: [
      'NYC closing costs for buyers can reach 4-6% of purchase price.',
      'Co-op maintenance fees often add $1,000-$2,500/month on top of the mortgage.',
      'Manhattan condos carry a median price above $1 million.',
      'Outer boroughs like Queens and the Bronx offer entry prices 40-60% below Manhattan.',
    ],
    faqItems: [
      {
        question: 'Should I buy or rent in New York City?',
        answer:
          'For most NYC residents, renting makes more financial sense unless you plan to stay at least 7-10 years. High purchase prices, co-op fees, and transaction costs push the break-even point further out. The outer boroughs have a shorter break-even timeline than Manhattan.',
      },
      {
        question: 'What are co-op fees and how do they affect buying costs?',
        answer:
          'Co-op maintenance fees cover building operations, property taxes, and sometimes underlying mortgage payments. They typically range from $800-$2,500/month and must be added to your mortgage payment when calculating the true cost of ownership.',
      },
      {
        question: 'Is it cheaper to buy in the outer boroughs?',
        answer:
          'Median prices in Brooklyn, Queens, the Bronx, and Staten Island are significantly lower than Manhattan. The break-even timeline versus renting can be 4-6 years in some outer-borough neighborhoods compared to 7-10+ years in Manhattan.',
      },
    ],
  },
  {
    slug: 'los-angeles',
    name: 'Los Angeles',
    stateSlug: 'california',
    stateName: 'California',
    medianHomePrice: 925000,
    medianMonthlyRent: 2800,
    priceToRentRatio: 27.5,
    avgAnnualAppreciation: 5.5,
    propertyTaxRate: 0.76,
    neighborhoodContext:
      'Los Angeles sprawls across a vast metro area with enormous price variation. Westside neighborhoods command premiums, while the Inland Empire offers more affordability.',
    blufVerdict:
      'Renting is typically more cost-effective than buying in Los Angeles for stays under 7 years. High prices and a steep price-to-rent ratio mean the opportunity cost of a down payment is significant.',
    keyFacts: [
      'LA median home prices are roughly double the national median.',
      'Prop 13 caps property tax increases at 2% per year for existing owners.',
      'The Inland Empire offers entry prices 40-50% below central LA.',
      'Earthquake insurance adds cost that many other cities do not have.',
    ],
    faqItems: [
      {
        question: 'Is it worth buying a home in Los Angeles?',
        answer:
          'LA has historically rewarded long-term homeowners with strong appreciation. However, the high entry cost means your down payment could earn competitive returns invested elsewhere. Buying makes sense for stays of 7+ years if you can manage the monthly costs comfortably.',
      },
      {
        question: 'How much does earthquake insurance cost in LA?',
        answer:
          'California Earthquake Authority premiums vary by location, construction type, and coverage. Typical costs range from $800-$3,000/year for a median-priced home. Standard homeowners insurance does not cover earthquake damage.',
      },
    ],
  },
  {
    slug: 'chicago',
    name: 'Chicago',
    stateSlug: 'illinois',
    stateName: 'Illinois',
    medianHomePrice: 320000,
    medianMonthlyRent: 1750,
    priceToRentRatio: 15.2,
    avgAnnualAppreciation: 3.5,
    propertyTaxRate: 2.27,
    neighborhoodContext:
      'Chicago offers a wide range of neighborhoods with dramatically different price points. North Side and Loop-adjacent areas command premiums, while South and West Side neighborhoods are much more affordable.',
    blufVerdict:
      'Chicago has relatively affordable purchase prices, but very high property taxes significantly increase the monthly cost of ownership. The buy-vs-rent decision hinges heavily on your specific neighborhood and tax district.',
    keyFacts: [
      'Chicago property taxes can exceed $6,000-$10,000/year on a median-priced home.',
      'North Side neighborhoods like Lincoln Park have median prices 2-3x the citywide median.',
      'The city has a transfer tax of $5.25 per $500 of sale price.',
      'Condo assessments in high-rise buildings add significant monthly cost.',
    ],
    faqItems: [
      {
        question: 'How do Chicago property taxes affect the buy decision?',
        answer:
          'At an effective rate of roughly 2.27%, property taxes on a $320,000 home total about $7,264/year or $605/month. In some suburban Cook County townships, rates are even higher. This is the single biggest factor tilting the Chicago buy-vs-rent equation.',
      },
      {
        question: 'Which Chicago neighborhoods are most affordable to buy?',
        answer:
          'South and Southwest Side neighborhoods, along with many near-west suburbs, offer entry prices well below the citywide median. However, appreciation rates have been slower in these areas compared to the North Side.',
      },
    ],
  },
  {
    slug: 'houston',
    name: 'Houston',
    stateSlug: 'texas',
    stateName: 'Texas',
    medianHomePrice: 295000,
    medianMonthlyRent: 1400,
    priceToRentRatio: 17.6,
    avgAnnualAppreciation: 4.0,
    propertyTaxRate: 2.03,
    neighborhoodContext:
      'Houston is a sprawling metro with no zoning laws, creating a diverse mix of housing types and price points. Energy industry cycles significantly influence the local economy.',
    blufVerdict:
      'Houston offers affordable home prices by major-city standards, but high property taxes and flood risk add to the true cost. Buying favors renters after about 4 years in most neighborhoods.',
    keyFacts: [
      'Houston has no zoning laws, leading to diverse housing stock.',
      'Property taxes in Harris County average over 2%.',
      'Flood insurance is critical in many Houston-area locations.',
      'No state income tax improves overall affordability.',
    ],
    faqItems: [
      {
        question: 'Do I need flood insurance in Houston?',
        answer:
          'Many Houston-area homes are in flood-prone zones. Even outside FEMA-designated flood zones, flooding risk exists due to the flat terrain and heavy rainfall. Flood insurance costs $500-$3,000+/year depending on location and elevation.',
      },
      {
        question: 'How do Houston property taxes compare to other Texas cities?',
        answer:
          'Houston (Harris County) property taxes average about 2.03%, slightly above the Texas statewide average of 1.80%. Rates vary by school district, MUD, and other special taxing districts.',
      },
    ],
  },
  {
    slug: 'phoenix',
    name: 'Phoenix',
    stateSlug: 'arizona',
    stateName: 'Arizona',
    medianHomePrice: 430000,
    medianMonthlyRent: 1600,
    priceToRentRatio: 22.4,
    avgAnnualAppreciation: 5.5,
    propertyTaxRate: 0.62,
    neighborhoodContext:
      'The Phoenix metro includes Scottsdale, Tempe, Mesa, Gilbert, and Chandler, each with different price profiles. Scottsdale is the premium submarket.',
    blufVerdict:
      'Phoenix has seen strong population-driven appreciation. Low property taxes help buyers, but rapid price increases have stretched affordability. Buying is favorable for stays of 5+ years.',
    keyFacts: [
      'Phoenix metro population growth has been among the fastest in the U.S.',
      'Property taxes are well below the national average.',
      'Scottsdale median prices are roughly double the metro average.',
      'Water availability is an emerging long-term consideration.',
    ],
    faqItems: [
      {
        question: 'Is the Phoenix housing market overheated?',
        answer:
          'Phoenix experienced rapid appreciation from 2020-2022 with some subsequent cooling. Strong population inflows continue to support demand, but affordability constraints and water supply questions are emerging factors.',
      },
      {
        question: 'How does water scarcity affect Phoenix home values?',
        answer:
          'Water availability is a growing concern for the Phoenix metro. While the city has invested in water infrastructure and conservation, long-term drought conditions in the Colorado River basin create uncertainty for future development.',
      },
    ],
  },
  {
    slug: 'philadelphia',
    name: 'Philadelphia',
    stateSlug: 'pennsylvania',
    stateName: 'Pennsylvania',
    medianHomePrice: 265000,
    medianMonthlyRent: 1500,
    priceToRentRatio: 14.7,
    avgAnnualAppreciation: 4.2,
    propertyTaxRate: 1.58,
    neighborhoodContext:
      'Philadelphia offers remarkable variety from Center City luxury to affordable row-home neighborhoods. The city wage tax is a unique cost factor for residents.',
    blufVerdict:
      'Philadelphia has one of the lowest price-to-rent ratios among major U.S. cities, making buying favorable relatively quickly. However, the city wage tax and property taxes add ongoing costs.',
    keyFacts: [
      'Philadelphia\'s price-to-rent ratio is among the lowest of major U.S. cities.',
      'The city levies a 3.75% wage tax on residents.',
      'Row homes dominate the housing stock in most neighborhoods.',
      'Gentrification patterns are reshaping neighborhood price maps.',
    ],
    faqItems: [
      {
        question: 'How does the Philadelphia wage tax affect housing decisions?',
        answer:
          'Philadelphia\'s 3.75% wage tax applies to all residents regardless of where they work. This adds significant cost to living in the city proper and is one reason many buyers consider nearby suburbs in Delaware County, Montgomery County, or New Jersey.',
      },
      {
        question: 'Why is Philadelphia relatively affordable among major East Coast cities?',
        answer:
          'Philadelphia benefits from a large existing housing stock (especially row homes), a population that only recently stabilized after decades of decline, and lower demand pressure compared to New York or Boston.',
      },
    ],
  },
  {
    slug: 'san-antonio',
    name: 'San Antonio',
    stateSlug: 'texas',
    stateName: 'Texas',
    medianHomePrice: 270000,
    medianMonthlyRent: 1300,
    priceToRentRatio: 17.3,
    avgAnnualAppreciation: 3.8,
    propertyTaxRate: 1.95,
    neighborhoodContext:
      'San Antonio is one of the most affordable major cities in Texas, with a strong military presence and a growing healthcare sector. The north side and Hill Country suburbs carry premiums.',
    blufVerdict:
      'San Antonio offers affordable homeownership for a major U.S. city. High property taxes are the main concern, but low prices keep the total monthly cost manageable. Buying is favorable after 3-4 years.',
    keyFacts: [
      'San Antonio is one of the most affordable top-15 U.S. cities.',
      'Military installations are a major economic driver.',
      'Property taxes in Bexar County average about 1.95%.',
      'No state income tax improves overall affordability.',
    ],
    faqItems: [
      {
        question: 'Is San Antonio a good city for first-time homebuyers?',
        answer:
          'San Antonio is frequently ranked among the best cities for first-time buyers due to affordable prices, steady job growth, and a low cost of living. The main caveat is high Texas property taxes.',
      },
    ],
  },
  {
    slug: 'san-diego',
    name: 'San Diego',
    stateSlug: 'california',
    stateName: 'California',
    medianHomePrice: 875000,
    medianMonthlyRent: 2700,
    priceToRentRatio: 27.0,
    avgAnnualAppreciation: 5.5,
    propertyTaxRate: 0.76,
    neighborhoodContext:
      'San Diego combines coastal lifestyle with a military and biotech-driven economy. Coastal neighborhoods command significant premiums over inland areas like Escondido and El Cajon.',
    blufVerdict:
      'San Diego has very high home prices that make renting more practical for stays under 7 years. Strong appreciation rewards long-term owners, but the entry cost is steep.',
    keyFacts: [
      'San Diego median prices are among the highest in the nation.',
      'Military and biotech sectors anchor the local economy.',
      'Coastal properties command 50-100% premiums over inland areas.',
      'Prop 13 limits property tax growth for long-term owners.',
    ],
    faqItems: [
      {
        question: 'Is renting smarter than buying in San Diego?',
        answer:
          'For stays under 7 years, renting is generally more cost-effective in San Diego due to the high price-to-rent ratio. Investing the down payment elsewhere often yields competitive returns. For stays of 7+ years, buying has historically built significant equity.',
      },
    ],
  },
  {
    slug: 'dallas',
    name: 'Dallas',
    stateSlug: 'texas',
    stateName: 'Texas',
    medianHomePrice: 350000,
    medianMonthlyRent: 1550,
    priceToRentRatio: 18.8,
    avgAnnualAppreciation: 4.5,
    propertyTaxRate: 1.93,
    neighborhoodContext:
      'The Dallas-Fort Worth metroplex is one of the largest and fastest-growing metro areas in the U.S. Corporate relocations have driven steady demand, especially in Frisco, Plano, and McKinney.',
    blufVerdict:
      'Dallas offers moderate home prices for a major metro, but high Texas property taxes add significant monthly cost. Buying is favorable after about 4 years if you can absorb the tax burden.',
    keyFacts: [
      'DFW is one of the largest and fastest-growing metros in the country.',
      'Corporate relocations have driven sustained housing demand.',
      'Property taxes in Dallas County average about 1.93%.',
      'Northern suburbs like Frisco and McKinney have seen the strongest appreciation.',
    ],
    faqItems: [
      {
        question: 'Is Dallas affordable compared to other major metros?',
        answer:
          'Dallas is more affordable than coastal metros like LA, NYC, or San Francisco, but prices have risen faster than the national average. When you factor in Texas property taxes, the monthly cost of ownership is higher than the price alone suggests.',
      },
    ],
  },
  {
    slug: 'austin',
    name: 'Austin',
    stateSlug: 'texas',
    stateName: 'Texas',
    medianHomePrice: 450000,
    medianMonthlyRent: 1700,
    priceToRentRatio: 22.1,
    avgAnnualAppreciation: 4.8,
    propertyTaxRate: 1.85,
    neighborhoodContext:
      'Austin has become one of the hottest housing markets in the country, driven by tech industry growth. Prices have cooled from 2022 peaks but remain well above pre-pandemic levels.',
    blufVerdict:
      'Austin is the most expensive major Texas city. High prices combined with high property taxes make renting more favorable for stays under 5 years. Long-term buyers benefit from strong fundamentals.',
    keyFacts: [
      'Austin experienced 40%+ price increases between 2020-2022 with subsequent correction.',
      'Tech industry expansion has been the primary demand driver.',
      'Property taxes in Travis County are among the highest in Texas.',
      'Surrounding suburbs like Round Rock and Cedar Park offer lower prices.',
    ],
    faqItems: [
      {
        question: 'Have Austin home prices come down from their peak?',
        answer:
          'Austin prices corrected 10-15% from the 2022 peak in many submarkets but remain 25-35% above pre-pandemic levels. The market has stabilized but is no longer seeing the rapid appreciation of 2020-2022.',
      },
      {
        question: 'Is it better to buy in Austin suburbs?',
        answer:
          'Suburbs like Round Rock, Cedar Park, and Pflugerville offer prices 20-30% below central Austin with good access to employment centers. Property taxes may still be high depending on the school district.',
      },
    ],
  },
  {
    slug: 'jacksonville',
    name: 'Jacksonville',
    stateSlug: 'florida',
    stateName: 'Florida',
    medianHomePrice: 340000,
    medianMonthlyRent: 1450,
    priceToRentRatio: 19.5,
    avgAnnualAppreciation: 5.0,
    propertyTaxRate: 0.89,
    neighborhoodContext:
      'Jacksonville is the largest city by land area in the continental U.S., offering a range of neighborhoods from beachside to urban core to rural suburban. It is one of the more affordable Florida metros.',
    blufVerdict:
      'Jacksonville is one of Florida\'s more affordable major cities. Buying is favorable after 4 years, especially with the homestead exemption. Insurance costs remain the key variable.',
    keyFacts: [
      'Jacksonville is the most affordable major Florida metro.',
      'The homestead exemption reduces property tax burdens for primary residents.',
      'Homeowners insurance has risen significantly in recent years.',
      'Naval Station Mayport and other military installations drive local demand.',
    ],
    faqItems: [
      {
        question: 'Is Jacksonville a good place to buy compared to other Florida cities?',
        answer:
          'Jacksonville offers lower entry prices than Miami, Tampa, or Orlando while still benefiting from Florida\'s no-income-tax environment. The tradeoff is less appreciation potential compared to South Florida.',
      },
    ],
  },
  {
    slug: 'miami',
    name: 'Miami',
    stateSlug: 'florida',
    stateName: 'Florida',
    medianHomePrice: 580000,
    medianMonthlyRent: 2400,
    priceToRentRatio: 20.1,
    avgAnnualAppreciation: 5.8,
    propertyTaxRate: 0.89,
    neighborhoodContext:
      'Miami is a global city with significant international buyer demand. Condo supply, insurance costs, and sea-level rise are unique factors in the buy-vs-rent analysis.',
    blufVerdict:
      'Miami home prices have risen sharply, driven by domestic migration and international demand. Insurance and condo fees are major ongoing costs. Buying is favorable after 5-6 years for those who can manage the total expense.',
    keyFacts: [
      'Miami has significant international buyer demand, especially from Latin America.',
      'Condo HOA fees in Miami often exceed $500-$1,000/month.',
      'Homeowners insurance premiums are among the highest in the nation.',
      'Sea-level rise is a long-term consideration for coastal properties.',
    ],
    faqItems: [
      {
        question: 'How do Miami condo fees affect the buy-vs-rent decision?',
        answer:
          'Miami condo HOA fees typically range from $400-$1,500/month and cover building maintenance, insurance, and amenities. These fees must be added to your mortgage payment when comparing to rent. They can make buying a condo comparable to or more expensive than renting.',
      },
      {
        question: 'Should I worry about sea-level rise when buying in Miami?',
        answer:
          'Sea-level rise is a documented concern for Miami-Dade County. Insurance costs are already reflecting this risk. Properties at higher elevations within the metro are commanding premiums. Consider flood risk, elevation, and long-term insurance trends when making a purchase decision.',
      },
    ],
  },
  {
    slug: 'atlanta',
    name: 'Atlanta',
    stateSlug: 'georgia',
    stateName: 'Georgia',
    medianHomePrice: 385000,
    medianMonthlyRent: 1650,
    priceToRentRatio: 19.4,
    avgAnnualAppreciation: 5.2,
    propertyTaxRate: 0.92,
    neighborhoodContext:
      'Atlanta is a sprawling metro with dramatic price variation between intown neighborhoods (Buckhead, Midtown) and suburban communities. The BeltLine project has significantly influenced neighborhood valuations.',
    blufVerdict:
      'Atlanta offers moderate prices for a major metro, with below-average property taxes. Buying is favorable after 4 years. Intown neighborhoods are pricier but appreciate faster.',
    keyFacts: [
      'Atlanta has attracted numerous corporate headquarters in recent years.',
      'The BeltLine trail project has driven appreciation in adjacent neighborhoods.',
      'Property taxes are near the national average.',
      'Northern suburbs like Alpharetta and Roswell offer strong schools with moderate prices.',
    ],
    faqItems: [
      {
        question: 'Is it better to buy intown Atlanta or in the suburbs?',
        answer:
          'Intown neighborhoods like Midtown and East Atlanta offer walkability and stronger appreciation but at higher prices. Suburbs like Marietta, Roswell, and Decatur offer more space and lower per-square-foot prices with good school access.',
      },
    ],
  },
  {
    slug: 'charlotte',
    name: 'Charlotte',
    stateSlug: 'north-carolina',
    stateName: 'North Carolina',
    medianHomePrice: 370000,
    medianMonthlyRent: 1550,
    priceToRentRatio: 19.9,
    avgAnnualAppreciation: 5.3,
    propertyTaxRate: 0.84,
    neighborhoodContext:
      'Charlotte is one of the fastest-growing metros in the Southeast, anchored by the banking and finance sector. SouthEnd and uptown areas command premiums, while outer suburbs remain affordable.',
    blufVerdict:
      'Charlotte combines moderate prices, low property taxes, and strong growth fundamentals. Buying is favorable after 3-4 years, making it one of the better buy-vs-rent markets among growing metros.',
    keyFacts: [
      'Charlotte is the second-largest banking center in the U.S.',
      'Property taxes in Mecklenburg County are below the national average.',
      'Population growth has consistently outpaced the national rate.',
      'Light rail expansion is influencing neighborhood appreciation patterns.',
    ],
    faqItems: [
      {
        question: 'Is Charlotte a good city for homebuyers in 2025?',
        answer:
          'Charlotte offers a combination of job growth, moderate prices, low taxes, and quality of life that makes it attractive for buyers. The main risk is that rapid growth could moderate if economic conditions shift, but long-term fundamentals remain strong.',
      },
    ],
  },
  {
    slug: 'denver',
    name: 'Denver',
    stateSlug: 'colorado',
    stateName: 'Colorado',
    medianHomePrice: 565000,
    medianMonthlyRent: 1900,
    priceToRentRatio: 24.8,
    avgAnnualAppreciation: 5.0,
    propertyTaxRate: 0.51,
    neighborhoodContext:
      'Denver sits at the base of the Rocky Mountains and has been one of the top destinations for domestic migration. Extremely low property taxes are a distinct advantage, but high prices extend the break-even timeline.',
    blufVerdict:
      'Denver has high home prices but exceptionally low property taxes. Buying is favorable after 5-6 years. The combination of lifestyle appeal and job growth supports long-term value.',
    keyFacts: [
      'Denver has some of the lowest property tax rates among major U.S. metros.',
      'Tech sector growth has been a major demand driver.',
      'Home prices are well above the national median but below coastal cities.',
      'Suburban markets like Aurora and Lakewood offer lower entry points.',
    ],
    faqItems: [
      {
        question: 'How do Denver property taxes compare to other cities?',
        answer:
          'Denver property taxes average about 0.51%, far below cities like Chicago (2.27%), Houston (2.03%), or Philadelphia (1.58%). On a $565,000 home, that is only about $2,882/year or $240/month — a significant cost advantage.',
      },
      {
        question: 'Is the Denver housing market cooling off?',
        answer:
          'Denver has seen some price moderation after rapid appreciation through 2022. Inventory has increased from historic lows, giving buyers more negotiating power. Long-term demand drivers (population growth, outdoor lifestyle, tech employment) remain intact.',
      },
    ],
  },
];

export function getCityBySlug(
  stateSlug: string,
  citySlug: string
): CityConfig | undefined {
  return cities.find(
    (c) => c.stateSlug === stateSlug && c.slug === citySlug
  );
}

export function getCitiesByState(stateSlug: string): CityConfig[] {
  return cities.filter((c) => c.stateSlug === stateSlug);
}

export function getAllCitySlugs(): { state: string; city: string }[] {
  return cities.map((c) => ({ state: c.stateSlug, city: c.slug }));
}
