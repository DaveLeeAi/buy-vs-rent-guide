import { Breadcrumb } from '@/components/layout/Breadcrumb';
import { BlufSummary } from '@/components/content/BlufSummary';
import { TrustNotice } from '@/components/content/TrustNotice';
import { LimitationsNotice } from '@/components/content/LimitationsNotice';
import { LocalDataPanel } from '@/components/content/LocalDataPanel';
import { ContentBlock } from '@/components/content/ContentBlock';
import { FaqModule } from '@/components/content/FaqModule';
import { InternalLinks } from '@/components/content/InternalLinks';
import { CalculatorShell } from '@/components/calculator/CalculatorShell';
import { SchemaMarkup } from '@/components/seo/SchemaMarkup';
import { buildWebPageSchema } from '@/lib/schema';
import { CityConfig } from '@/config/types';
import { getCitiesByState } from '@/config/cities';
import { siteConfig } from '@/config/siteConfig';

interface CityPageTemplateProps {
  city: CityConfig;
}

export function CityPageTemplate({ city }: CityPageTemplateProps) {
  const siblingCities = getCitiesByState(city.stateSlug).filter(
    (c) => c.slug !== city.slug
  );
  const url = `${siteConfig.baseUrl}/buy-vs-rent/${city.stateSlug}/${city.slug}`;

  const relatedLinks = [
    {
      label: `${city.stateName} State Overview`,
      href: `/buy-vs-rent/${city.stateSlug}`,
      description: `Statewide data for ${city.stateName}.`,
    },
    ...siblingCities.map((c) => ({
      label: `${c.name}, ${c.stateName}`,
      href: `/buy-vs-rent/${c.stateSlug}/${c.slug}`,
      description: `Compare with ${c.name}.`,
    })),
    {
      label: 'National Calculator',
      href: '/buy-vs-rent',
      description: 'Compare with national averages.',
    },
    {
      label: 'Methodology',
      href: '/methodology',
      description: 'How we calculate these numbers.',
    },
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <SchemaMarkup
        data={buildWebPageSchema(
          `Buy vs. Rent in ${city.name}, ${city.stateName}`,
          `Should you buy or rent in ${city.name}? Free calculator with local market data.`,
          url
        )}
      />

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Buy vs. Rent', href: '/buy-vs-rent' },
          { label: city.stateName, href: `/buy-vs-rent/${city.stateSlug}` },
          {
            label: city.name,
            href: `/buy-vs-rent/${city.stateSlug}/${city.slug}`,
          },
        ]}
      />

      <h1 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
        Buy vs. Rent in {city.name}, {city.stateName}
      </h1>

      <BlufSummary
        verdict={city.blufVerdict}
        context={city.neighborhoodContext}
      />

      <TrustNotice />

      <LocalDataPanel
        medianHomePrice={city.medianHomePrice}
        medianMonthlyRent={city.medianMonthlyRent}
        priceToRentRatio={city.priceToRentRatio}
        propertyTaxRate={city.propertyTaxRate}
        avgAnnualAppreciation={city.avgAnnualAppreciation}
        keyFacts={city.keyFacts}
      />

      <ContentBlock heading={`Using the Calculator for ${city.name}`}>
        <p className="mb-3">
          The calculator below is pre-filled with {city.name} market data,
          including a median home price of $
          {city.medianHomePrice.toLocaleString()} and median rent of $
          {city.medianMonthlyRent.toLocaleString()}/month. Adjust any values to
          match your specific neighborhood and situation.
        </p>
        <p>
          Property tax is set to {city.propertyTaxRate}%, which is the local
          average effective rate. Your actual rate may differ based on your exact
          location and any applicable exemptions.
        </p>
      </ContentBlock>

      <CalculatorShell
        defaultOverrides={{
          homePrice: city.medianHomePrice,
          monthlyRent: city.medianMonthlyRent,
          propertyTaxRate: city.propertyTaxRate,
          homeAppreciationRate: city.avgAnnualAppreciation,
        }}
      />

      <div className="mt-10">
        <LimitationsNotice />
      </div>

      <FaqModule
        items={city.faqItems}
        heading={`${city.name} FAQ`}
      />

      <InternalLinks heading="Related Pages" links={relatedLinks} />
    </div>
  );
}
