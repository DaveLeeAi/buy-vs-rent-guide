import { Breadcrumb } from '@/components/layout/Breadcrumb';
import { BlufSummary } from '@/components/content/BlufSummary';
import { TrustNotice } from '@/components/content/TrustNotice';
import { LimitationsNotice } from '@/components/content/LimitationsNotice';
import { LocalDataPanel } from '@/components/content/LocalDataPanel';
import { ContentBlock } from '@/components/content/ContentBlock';
import { FaqModule } from '@/components/content/FaqModule';
import { InternalLinks } from '@/components/content/InternalLinks';
import { CalculatorShell } from '@/components/calculator/CalculatorShell';
import { SchemaMarkup } from '@/components/seo/SchemaMarkup';
import { buildWebPageSchema } from '@/lib/schema';
import { StateConfig } from '@/config/types';
import { getCitiesByState } from '@/config/cities';
import { siteConfig } from '@/config/siteConfig';

interface StatePageTemplateProps {
  state: StateConfig;
}

export function StatePageTemplate({ state }: StatePageTemplateProps) {
  const stateCities = getCitiesByState(state.slug);
  const url = `${siteConfig.baseUrl}/buy-vs-rent/${state.slug}`;

  const relatedLinks = [
    {
      label: 'National Buy vs. Rent Calculator',
      href: '/buy-vs-rent',
      description: 'Compare with national averages.',
    },
    ...stateCities.map((c) => ({
      label: `${c.name}, ${state.name}`,
      href: `/buy-vs-rent/${state.slug}/${c.slug}`,
      description: `Local data for ${c.name}.`,
    })),
    {
      label: 'Methodology',
      href: '/methodology',
      description: 'How we calculate these numbers.',
    },
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <SchemaMarkup
        data={buildWebPageSchema(
          `Buy vs. Rent in ${state.name}`,
          `Should you buy or rent in ${state.name}? Free calculator with local data.`,
          url
        )}
      />

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Buy vs. Rent', href: '/buy-vs-rent' },
          { label: state.name, href: `/buy-vs-rent/${state.slug}` },
        ]}
      />

      <h1 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
        Buy vs. Rent in {state.name}
      </h1>

      <BlufSummary verdict={state.blufVerdict} />

      <TrustNotice />

      <LocalDataPanel
        medianHomePrice={state.medianHomePrice}
        medianMonthlyRent={state.medianMonthlyRent}
        priceToRentRatio={state.priceToRentRatio}
        propertyTaxRate={state.propertyTaxRate}
        avgAnnualAppreciation={state.avgAnnualAppreciation}
        keyFacts={state.keyFacts}
      />

      <ContentBlock heading={`Using the Calculator for ${state.name}`}>
        <p className="mb-3">
          The calculator below is pre-filled with {state.name} market data,
          including the statewide median home price of $
          {state.medianHomePrice.toLocaleString()} and median rent of $
          {state.medianMonthlyRent.toLocaleString()}/month. Adjust any values to
          match your specific situation.
        </p>
        <p>
          Property tax is set to {state.propertyTaxRate}%, which is the statewide
          average effective rate. Your actual rate may differ based on your county
          and municipality.
        </p>
      </ContentBlock>

      <CalculatorShell
        defaultOverrides={{
          homePrice: state.medianHomePrice,
          monthlyRent: state.medianMonthlyRent,
          propertyTaxRate: state.propertyTaxRate,
          homeAppreciationRate: state.avgAnnualAppreciation,
        }}
      />

      <div className="mt-10">
        <LimitationsNotice />
      </div>

      <FaqModule items={state.faqItems} heading={`${state.name} FAQ`} />

      <InternalLinks heading="Related Pages" links={relatedLinks} />
    </div>
  );
}
